from urllib.request import urlopen


data = "language=python&framework=django"
f = urlopen("http://127.0.0.1:8000", bytes(data, encoding='utf-8'))

print(f.read().decode('utf-8'))
